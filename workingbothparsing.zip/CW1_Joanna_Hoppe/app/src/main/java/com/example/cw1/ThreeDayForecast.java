package com.example.cw1;

    public class ThreeDayForecast {
        private String conditionDay1;
        private String conditionDay2;
        private String conditionDay3;

        public ThreeDayForecast() {}

        public String getConditionDay1() {
            return conditionDay1;
        }

        public void setConditionDay1(String conditionDay1) {
            this.conditionDay1 = conditionDay1;
        }

        public String getConditionDay2() {
            return conditionDay2;
        }

        public void setConditionDay2(String conditionDay2) {
            this.conditionDay2 = conditionDay2;
        }

        public String getConditionDay3() {
            return conditionDay3;
        }

        public void setConditionDay3(String conditionDay3) {
            this.conditionDay3 = conditionDay3;
        }
    }

